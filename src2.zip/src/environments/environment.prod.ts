export const environment = {
  production: true,
  firebase : {
    apiKey: 'AIzaSyAlpwx_EdxRNXc27ufBBTppZIZSnOk4_7Y',
    authDomain: 'lcfd-protocols.firebaseapp.com',
    projectId: 'lcfd-protocols',
    storageBucket: 'lcfd-protocols.appspot.com',
    messagingSenderId: '576229609728',
    appId: '1:576229609728:web:dc1671a0bafd09f12e23e5',
    measurementId: 'G-8V2G3XHFMR'
  }
};
